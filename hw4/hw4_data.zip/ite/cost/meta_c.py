""" Meta cross-quantity estimators. """
